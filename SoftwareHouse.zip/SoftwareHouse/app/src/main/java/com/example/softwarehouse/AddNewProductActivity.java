package com.example.softwarehouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.UUID;

public class AddNewProductActivity extends AppCompatActivity {
    // Uri indicates, where the image will be picked from
    private Uri filePath;
    private boolean stopUserInteractions;
    // request code
    private final int PICK_IMAGE_REQUEST = 22;

    // instance for firebase storage and StorageReference
    FirebaseStorage storage;
    StorageReference storageReference;
    final Handler ha=new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_product);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        setUpButtonInput();
        ((Button)findViewById(R.id.button_categoryNewProduct)).setText("Games");
        stopUserInteractions = false;

        ha.postDelayed(new Runnable() {

            @Override
            public void run() {
                //call function
                ImageView tickImage = findViewById(R.id.tickNewProductImageAdmin);
                ImageView tickTitle = findViewById(R.id.tickNewProductTitleAdmin);
                ImageView tickPrice = findViewById(R.id.tickNewProductPriceAdmin);
                ImageView tickDescription = findViewById(R.id.tickNewProductDescritionAdmin);
                TextView uploadimageText = findViewById(R.id.uploadimageTextAdmin);


                if(validationImage(filePath) > 0){
                    tickImage.setVisibility(View.VISIBLE);
                    uploadimageText.setVisibility(View.GONE);
                }
                else{
                    tickImage.setVisibility(View.INVISIBLE);
                    uploadimageText.setVisibility(View.VISIBLE);
                }


                EditText titleText = findViewById(R.id.editText_titleNewProduct);
                if(validationTitle(titleText.getText().toString()) > 0){
                    tickTitle.setVisibility(View.VISIBLE);
                }
                else{
                    tickTitle.setVisibility(View.INVISIBLE);
                }


                EditText priceText = findViewById(R.id.editText_priceNewProduct);
                if(validationPrice(priceText.getText().toString()) > 0){
                    tickPrice.setVisibility(View.VISIBLE);
                }
                else{
                    tickPrice.setVisibility(View.INVISIBLE);
                }

                EditText descriptionText = findViewById(R.id.editText_descriptionNewProduct);
                if(validationDescription(descriptionText.getText().toString()) > 0){
                    tickDescription.setVisibility(View.VISIBLE);
                }
                else{
                    tickDescription.setVisibility(View.INVISIBLE);
                }




                ha.postDelayed(this, 1);
            }
        }, 100);
    }


    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (stopUserInteractions) {
            return true;
        } else {
            return super.dispatchTouchEvent(ev);
        }
    }

    public void setUpButtonInput(){
        Button category = findViewById(R.id.button_categoryNewProduct);
        Button promotion = findViewById(R.id.button_promotionNewProduct);
        ImageButton image = findViewById(R.id.buntton_ImageProduct);
        ImageButton addProduct = findViewById(R.id.buntton_AddNewProduct);
        ImageView tickImage = findViewById(R.id.tickNewProductImageAdmin);
        ImageView tickTitle = (ImageView)findViewById(R.id.tickNewProductTitleAdmin);
        ImageView tickPrice = (ImageView)findViewById(R.id.tickNewProductPriceAdmin);
        ImageView tickDescription = (ImageView)findViewById(R.id.tickNewProductDescritionAdmin);

        tickImage.setVisibility(View.INVISIBLE);
        tickTitle.setVisibility(View.INVISIBLE);
        tickPrice.setVisibility(View.INVISIBLE);
        tickDescription.setVisibility(View.INVISIBLE);



        category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(AddNewProductActivity.this,view);
                popupMenu.getMenuInflater().inflate(R.menu.menu_add_new_product_category, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        category.setText(menuItem.getTitle().toString());
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        promotion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(AddNewProductActivity.this,view);
                popupMenu.getMenuInflater().inflate(R.menu.menu_add_new_product_promotion, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        promotion.setText(menuItem.getTitle().toString());
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                SelectImage();
            }
        });

        addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertNewProduct();
            }
        });

    }

    private void SelectImage(){
        // Defining Implicit Intent to mobile gallery
        Intent intent = new Intent();
        intent.setType("image/*");
        //intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        startActivityForResult(
                Intent.createChooser(
                        intent,
                        "Select Image from here..."),
                22);
    }

    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data)
    {

        super.onActivityResult(requestCode,
                resultCode,
                data);

        // checking request code and result code
        // if request code is PICK_IMAGE_REQUEST and
        // resultCode is RESULT_OK
        // then set image in the image view
        if (requestCode == 22
                && resultCode == RESULT_OK
                && data != null
                && data.getData() != null) {
            filePath = data.getData();
            ImageButton image = findViewById(R.id.buntton_ImageProduct);
            GlideApp.with(this).asBitmap().load(filePath).into(image);
            System.out.println("image caricata" + filePath);
        }

    }

    public void uploadImage(String pathFirebaseImage, String id) {
        if (filePath != null) {


            // Code for showing progressDialog while uploading
            ProgressDialog progressDialog
                    = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();




            // Defining the child of storageReference

            StorageReference ref
                    = storageReference
                    .child(pathFirebaseImage
                            );

            // adding listeners on upload
            // or failure of image
            ref.putFile(filePath)
                    .addOnSuccessListener(
                            new OnSuccessListener<UploadTask.TaskSnapshot>() {

                                @Override
                                public void onSuccess(
                                        UploadTask.TaskSnapshot taskSnapshot) {
                                    insertNewProductCallback();
                                    System.out.println("immagine salvata");
                                }
                            })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Firebase.DeleteProductsWithoutImage(id,AddNewProductActivity.this);

                        }
                    })

                    .addOnProgressListener(
                            new OnProgressListener<UploadTask.TaskSnapshot>() {

                                // Progress Listener for loading
                                // percentage on the dialog box
                                @Override
                                public void onProgress(
                                        UploadTask.TaskSnapshot taskSnapshot) {
                                    progressDialog.setCancelable(false);
                                    progressDialog.setCanceledOnTouchOutside(false);
                                    double progress
                                            = (100.0
                                            * taskSnapshot.getBytesTransferred()
                                            / taskSnapshot.getTotalByteCount());
                                    progressDialog.setMessage(
                                            "Adding product "
                                                    + (int) progress + "%");
                                }
                            });


        }
    }
    public void GoBack (View view){
        finish();
    }

    private void insertNewProduct(){
        Button categoryB = findViewById(R.id.button_categoryNewProduct);
        Button promotionB = findViewById(R.id.button_promotionNewProduct);
        String title = ((EditText) findViewById(R.id.editText_titleNewProduct)).getText().toString();
        String price = ((EditText) findViewById(R.id.editText_priceNewProduct)).getText().toString();
        String description = ((EditText) findViewById(R.id.editText_descriptionNewProduct)).getText().toString();
        String category = categoryB.getText().toString();
        String promotion = promotionB.getText().toString();
        if(promotion.equals("None"))promotion = "none";

        String image =  "images/"
                + UUID.randomUUID().toString();
        HashMap<String,Object> JSONproduct = new HashMap<>();


        if(validationInput(title,filePath,price,description) > 0) {
            //rounded price
            //String priceCorrect = price.replace(',','.');
            //Float priceFloat = Float.parseFloat(priceCorrect);
            //String priceRounded = String.format("%.2f", priceFloat);
            JSONproduct.put("image", image);
            JSONproduct.put("title", title);
            JSONproduct.put("description", description);
            JSONproduct.put("price", price);
            JSONproduct.put("rating", "0");
            JSONproduct.put("category", category);
            JSONproduct.put("promotion", promotion);
            JSONproduct.put("oldprice", "0");
            JSONproduct.put("numberRank", "0");
            stopUserInteractions = true;
            Firebase.SaveNewProduct(JSONproduct, this,image);
        }

        else{
            Toast.makeText(this.getApplicationContext(),"Insert All Data",
                    Toast.LENGTH_SHORT).show();
        }


    }

    private int validationTitle(String title){
        if(title == null||title.length() > 30 || title.length() < 1){
            return -1;
        }
        return 1;
    }

    private int validationImage(Uri image){
        if(image == null || image.toString().length() < 1){
            return -1;
        }
        return 1;
    }

    private int validationPrice(String price){
        if(price == null || price.length() < 1 || price.length() > 12){
            return -1;
        }
        return 1;
    }

    private int validationDescription(String description){
        if(description == null || description.length() < 1){
            return -1;
        }
        return 1;
    }


    private  int validationInput(String title, Uri image, String price, String description){
        int checkTitle = validationTitle(title);
        int checkImage = validationImage(image);
        int checkPrice = validationPrice(price);
        int checkDescription = validationDescription(description);
        if(checkTitle > 0 && checkImage > 0 && checkDescription > 0 && checkPrice >0){
            return 1;
        }
        else return -1;
    }


    public void insertNewProductCallback(){
        stopUserInteractions = false;
        finish();
    }

}
package com.example.softwarehouse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.softwarehouse.model.ProductModel;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.HashMap;

public class LoginActivity extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    Boolean stopUserInteractions;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        firebaseAuth.signOut();
        stopUserInteractions = false;
    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (stopUserInteractions) {
            return true;
        } else {
            return super.dispatchTouchEvent(ev);
        }
    }
    public void Login(View view){
        String email = ((EditText) findViewById(R.id.editText_LoginEmail)).getText().toString().toLowerCase();
        String password = ((EditText) findViewById(R.id.editText_LoginPassword)).getText().toString().toLowerCase();
        int checkValidation = ValidationInputLogin(email,password);
        if(checkValidation<0){
            String toast;
            if(checkValidation == -1){
                toast = "Email or Password Are To Short";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }

            else if(checkValidation == -2){
                toast = "Email Is Incorrect";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }

            else if(checkValidation == -3){
                toast = "Domain Not Supported";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }

            else if(checkValidation == -4){
                toast = "Email or Password are Empty";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }
        }

        else if(checkValidation > 0){
            stopUserInteractions = true;
            Firebase.Login(email,password,this);
        }

    }



    private int ValidationInputLogin(String email,String password){
        if(email.length() > 50 || password.length() > 15 || password.length() < 6){
            return -1;
        }
        int at = email.indexOf("@");
        if(at == -1){
            return -2;
        }

        String domain = email.substring(at+1);
        System.out.println(domain);
        if(!domain.equals("gmail.com") && !domain.equals("outlook.it") && !domain.equals("outlook.com") && !domain.equals("icloud.com") && !domain.equals("yahoo.com")&& !domain.equals("yahoo.it")&& !domain.equals("live.com")&& !domain.equals("hotmail.com")&& !domain.equals("hotmail.it")){
            return -3;
        }

        if(email.isEmpty() || password.isEmpty()){
            return -4;
        }

        return 1;
    }

    public void GetDataUser(String UID){
        Firebase.GetDataUser(UID,this);
    }
    public void CallbackLogin(int operationState,HashMap<String,Object> user,ArrayList<ProductModel> wishlist, String UID){
        String toast;
        if(operationState == 1){
            toast = "Login Succesfull";
            Toast.makeText(this.getApplicationContext(),toast,
                    Toast.LENGTH_SHORT).show();
            Intent intent;

            if(UID.equals("i7Pux9iGA6hIEt0hP3HotnVgvSC")){
                intent = new Intent(LoginActivity.this, HomeAdminActivity.class);
                intent.putExtra("user",user);
            }
            else{
                intent = new Intent(LoginActivity.this, HomeCustomerActivity.class);
                intent.putExtra("user",user);
                intent.putExtra("wishlist",wishlist);
                //((ArrayList<ProductModel>)user.get("wishlist")).forEach(productModel -> System.out.println(productModel.title));
            }

            startActivity(intent);
            finish();
        }

        else if(operationState == -1){
            stopUserInteractions = false;
            toast = "User doesn't exist or the email wasn't verified";
            Toast.makeText(this.getApplicationContext(),toast,
                    Toast.LENGTH_SHORT).show();
        }
    }



    public void GoToRegister(View view){
        startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
        finish();
        System.out.println("pressed");
    }
}
package com.example.softwarehouse.model;

import java.net.URL;

public class AdminModel extends UserModel{
    AdminModel(String UID, String name, String surname, String password, String email, URL photo){
        super(UID,name,surname,password,email);
    }
}



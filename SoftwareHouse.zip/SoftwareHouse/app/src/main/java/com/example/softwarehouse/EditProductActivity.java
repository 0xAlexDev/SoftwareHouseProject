package com.example.softwarehouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.UUID;

public class EditProductActivity extends AppCompatActivity {

    // Uri indicates, where the image will be picked from
    private Uri filePath;

    // request code
    private final int PICK_IMAGE_REQUEST = 22;
    final Handler ha=new Handler();

    // instance for firebase storage and StorageReference
    FirebaseStorage storage;
    StorageReference storageReference;
    String UID;
    String title;
    String image;
    String oldimage;
    String price;
    String description;
    String category;
    String rating;
    String promotion;
    String numberRank;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        UID = getIntent().getStringExtra("UID");
        title = getIntent().getStringExtra("title");
        image = getIntent().getStringExtra("image");
        oldimage = getIntent().getStringExtra("image");
        price = getIntent().getStringExtra("price");
        description = getIntent().getStringExtra("description");
        category = getIntent().getStringExtra("category");
        promotion = getIntent().getStringExtra("promotion");
        rating = getIntent().getStringExtra("rating");
        numberRank = getIntent().getStringExtra("numberRank");
        setUpButtonInput();

        ha.postDelayed(new Runnable() {

            @Override
            public void run() {
                //call function
                ImageView tickImage = findViewById(R.id.tickEditProductImageAdmin);
                ImageView tickTitle = findViewById(R.id.tickEditProductTitleAdmin);
                ImageView tickPrice = findViewById(R.id.tickEditProductPriceAdmin);
                ImageView tickDescription = findViewById(R.id.tickEditProductDescriptionAdmin);

                tickImage.setVisibility(View.VISIBLE);





                EditText titleText = findViewById(R.id.editText_titleeditProduct);
                if(validationTitle(titleText.getText().toString()) > 0){
                    tickTitle.setVisibility(View.VISIBLE);
                }
                else{
                    tickTitle.setVisibility(View.INVISIBLE);
                }


                EditText priceText = findViewById(R.id.editText_priceeditProduct);
                if(validationPrice(priceText.getText().toString()) > 0){
                    tickPrice.setVisibility(View.VISIBLE);
                }
                else{
                    tickPrice.setVisibility(View.INVISIBLE);
                }

                EditText descriptionText = findViewById(R.id.editText_descriptioneditProduct);
                if(validationDescription(descriptionText.getText().toString()) > 0){
                    tickDescription.setVisibility(View.VISIBLE);
                }
                else{
                    tickDescription.setVisibility(View.INVISIBLE);
                }




                ha.postDelayed(this, 1);
            }
        }, 100);




    }

    public void GoBack (View view){

        finish();
    }


    public void setUpButtonInput(){
        EditText EditTextTitle = findViewById(R.id.editText_titleeditProduct);
        EditText EditTextPrice = findViewById(R.id.editText_priceeditProduct);
        EditText EditTextDescription = findViewById(R.id.editText_descriptioneditProduct);
        Button categoryB = findViewById(R.id.button_categoryeditProduct);
        Button promotionB = findViewById(R.id.button_promotioneditProduct);
        ImageButton image = findViewById(R.id.buntton_ImageeditProduct);
        ImageButton addProduct = findViewById(R.id.buntton_AddeditProduct);
        EditTextTitle.setText(this.title);
        EditTextDescription.setText(this.description);
        EditTextPrice.setText(this.price);
        categoryB.setText(this.category);
        promotionB.setText(this.promotion);
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(this.image);
        GlideApp.with(this).asBitmap().load(storageReference).into(image);
        Button backButton = findViewById(R.id.button_categoryeditProduct);


        categoryB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(EditProductActivity.this,view);
                popupMenu.getMenuInflater().inflate(R.menu.menu_add_new_product_category, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        categoryB.setText(menuItem.getTitle().toString());
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        promotionB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(EditProductActivity.this,view);
                popupMenu.getMenuInflater().inflate(R.menu.menu_add_new_product_promotion, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        promotionB.setText(menuItem.getTitle().toString());
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                SelectImage();
            }
        });

        addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditProduct();
            }
        });

    }


    private void SelectImage(){
        // Defining Implicit Intent to mobile gallery
        Intent intent = new Intent();
        intent.setType("image/*");
        //intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        startActivityForResult(
                Intent.createChooser(
                        intent,
                        "Select Image from here..."),
                22);
    }

    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data)
    {

        super.onActivityResult(requestCode,
                resultCode,
                data);

        // checking request code and result code
        // if request code is PICK_IMAGE_REQUEST and
        // resultCode is RESULT_OK
        // then set image in the image view
        if (requestCode == 22
                && resultCode == RESULT_OK
                && data != null
                && data.getData() != null) {
            filePath = data.getData();
            ImageButton image = findViewById(R.id.buntton_ImageeditProduct);
            GlideApp.with(this).asBitmap().load(filePath).into(image);
            System.out.println("image caricata" + filePath);
        }

    }

    public void uploadImage(String pathFirebaseImage, String patholdimage) {
        if (filePath != null) {


            // Code for showing progressDialog while uploading
            ProgressDialog progressDialog
                    = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();




            // Defining the child of storageReference

            StorageReference ref
                    = storageReference
                    .child(pathFirebaseImage
                    );

            // adding listeners on upload
            // or failure of image
            System.out.println("------------- filepath: " + filePath);
            ref.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

                                @Override
                                public void onSuccess(
                                        UploadTask.TaskSnapshot taskSnapshot) {
                                    System.out.println("-------------- immagine nuova aggiunta" + pathFirebaseImage);
                                    StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(oldimage);
                                    System.out.println("-------------- provo ad eliminare" + patholdimage);

                                    if(patholdimage!=null) {
                                        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                System.out.println("-------------- Callback");
                                                EditProductCallback();
                                                // File deleted successfully
                                                //Log.d(TAG, "onSuccess: deleted file");
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception exception) {
                                                // Uh-oh, an error occurred!
                                                //Log.d(TAG, "onFailure: did not delete file");
                                            }
                                        });


                                    }


                                    System.out.println("immagine salvata");
                                }
                            })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {


                        }
                    })

                    .addOnProgressListener(
                            new OnProgressListener<UploadTask.TaskSnapshot>() {

                                // Progress Listener for loading
                                // percentage on the dialog box
                                @Override
                                public void onProgress(

                                        UploadTask.TaskSnapshot taskSnapshot) {
                                    progressDialog.setCancelable(false);
                                    progressDialog.setCanceledOnTouchOutside(false);
                                    double progress
                                            = (100.0
                                            * taskSnapshot.getBytesTransferred()
                                            / taskSnapshot.getTotalByteCount());
                                    progressDialog.setMessage(
                                            "Editing product "
                                                    + (int) progress + "%");
                                }
                            });


        }

        else{
            EditProductCallback();
        }
    }

    private void EditProduct(){
        String title = ((EditText)findViewById(R.id.editText_titleeditProduct)).getText().toString();
        String price = ((EditText)findViewById(R.id.editText_priceeditProduct)).getText().toString();
        String description = ((EditText) findViewById(R.id.editText_descriptioneditProduct)).getText().toString();
        String category = ((Button)findViewById(R.id.button_categoryeditProduct)).getText().toString();
        String promotion = ((Button)findViewById(R.id.button_promotioneditProduct)).getText().toString();

        if(promotion.equals("None"))promotion = "none";
        String image;
        HashMap<String,Object> JSONproduct = new HashMap<>();
        if(filePath != null){
            image =  "images/"
                    + UUID.randomUUID().toString();

        }
        else{
            image = this.image;
        }
        //rounded price



        if(validationInput(image,title,price,description,category,promotion) > 0) {
            //String priceCorrect = price.replace(',','.');
            //Float priceFloat = Float.parseFloat(priceCorrect);
            //String priceRounded = String.format("%.2f", priceFloat);

            JSONproduct.put("image", image);
            JSONproduct.put("title", title);
            JSONproduct.put("description", description);
            JSONproduct.put("price", price);
            JSONproduct.put("rating", this.rating);
            JSONproduct.put("category", category);
            JSONproduct.put("promotion", promotion);
            JSONproduct.put("oldprice", "0");
            JSONproduct.put("numberRank", numberRank);
            Firebase.ModifyProducts(UID,JSONproduct, this,image,oldimage);
        }
    }

    private int validationInput(String image,String title, String price, String description,String category,String promotion){
        //Write Rules
        if(image.isEmpty() || image.equals("")){
            return -1;
        }

        if(title.isEmpty() || title.equals("")){
            return -2;
        }

        if(price.isEmpty() || price.equals("")){
            return -3;
        }

        if(description.isEmpty() || description.equals("")){
            return -4;
        }

        if(category.isEmpty() || category.equals("")){
            return -5;
        }

        if(promotion.isEmpty() || promotion.equals("")){
            return -6;
        }
        return 1;
    }

    private int validationTitle(String title){
        if(title == null||title.length() > 30 || title.length() < 1){
            return -1;
        }
        return 1;
    }

    private int validationImage(Uri image){
        if(image == null || image.toString().length() < 1){
            return -1;
        }
        return 1;
    }

    private int validationPrice(String price){
        if(price == null || price.length() < 1 || price.length() > 12){
            return -1;
        }
        return 1;
    }

    private int validationDescription(String description){
        if(description == null || description.length() < 1){
            return -1;
        }
        return 1;
    }


    private  int validationInput(String title, Uri image, String price, String description){
        int checkTitle = validationTitle(title);
        int checkImage = validationImage(image);
        int checkPrice = validationPrice(price);
        int checkDescription = validationDescription(description);
        if(checkTitle > 0 && checkImage > 0 && checkDescription > 0 && checkPrice >0){
            return 1;
        }
        else return -1;
    }

    public void EditProductCallback(){
        finish();
    }




}
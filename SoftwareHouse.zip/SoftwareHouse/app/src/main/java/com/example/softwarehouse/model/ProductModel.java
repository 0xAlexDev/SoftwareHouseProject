package com.example.softwarehouse.model;

import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.io.Serializable;
import java.net.URL;

public class ProductModel implements Serializable {
    public String UID;
    public String image;
    public String title;
    public String description;
    public Double price;
    public Integer rating;
    public String category;
    public String promotion;
    public Double oldprice;
    public Integer numberRank;


    public ProductModel(String UID,String image, String title, String description, String category, Double price, Integer rating, String promotion,Double oldprice, Integer numberRank){
        this.UID = UID;
        this.title = title;
        this.image = image;
        this.description = description;
        this.price = price;
        this.rating = rating;
        this.category = category;
        this.promotion = promotion;
        this.oldprice = oldprice;
        this.numberRank = numberRank;
    }

}

package com.example.softwarehouse.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.softwarehouse.EditProductActivity;
import com.example.softwarehouse.Firebase;
import com.example.softwarehouse.GlideApp;
import com.example.softwarehouse.HomeAdminActivity;
import com.example.softwarehouse.HomeCustomerActivity;
import com.example.softwarehouse.MyAppGlideModule;
import com.example.softwarehouse.R;
import com.example.softwarehouse.WishListActivity;
import com.example.softwarehouse.model.CustomerModel;
import com.example.softwarehouse.model.ProductModel;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;


public class WishlistAdapter extends  RecyclerView.Adapter<WishlistAdapter.ViewHolder> {
    private static final String listID = "dynamicProductListAdmin";

    private  ArrayList<ProductModel> products = new ArrayList<>();
    private  ArrayList<ProductModel> AllProducts = new ArrayList<>();
    private Context context;
    private WishListActivity wishListActivity;
    private  CustomerModel customer;
    public WishlistAdapter(Context context, ArrayList<ProductModel> products,ArrayList<ProductModel> allProducts,  WishListActivity wishListActivity, CustomerModel customer){
        this.products = products;
        this.AllProducts = allProducts;
        this.context = context;
        this.wishListActivity = wishListActivity;
        this.customer = customer;

        for(ProductModel product : products){
            System.out.println("-----------------" + product.title);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_customer_product,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        System.out.println("----------------- titolo: "+ products.get(position).title);
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(products.get(position).image.toString());
        GlideApp.with(context).asBitmap().load(storageReference).into(holder.image);
        holder.UID.setText(products.get(position).UID);
        holder.title.setText(products.get(position).title);
        holder.description.setText(products.get(position).description);
        Double priceFloat = Double.parseDouble(products.get(position).price.toString());
        String priceRounded = String.format("%.2f", priceFloat);
        holder.price.setText(priceRounded.replace(".",",") + "$");


        Float rank;
        if(products.get(position).numberRank == 0){
            rank = new Float(0.0);
        }
        else{
            rank = new Float(products.get(position).rating/products.get(position).numberRank);
        }

        holder.ratingBar.setRating(rank);
        holder.category.setText(products.get(position).category);
        holder.promotion.setText(products.get(position).promotion);
        holder.oldprice.setText(products.get(position).oldprice.toString() + "$");
        System.out.println(products.get(position).numberRank);
        holder.numberRank.setText(products.get(position).numberRank.toString());




        holder.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String UID = products.get(position).UID.toString();
                String title = products.get(position).title.toString();
                String image = products.get(position).image.toString();
                String price = products.get(position).price.toString();
                String description = products.get(position).description.toString();
                String category = products.get(position).category.toString();
                String promotion = products.get(position).promotion.toString();
                String rating = products.get(position).rating.toString();
                String numberRank = products.get(position).numberRank.toString();
                System.out.println("show details oleeee");
                wishListActivity.ShowDetails(UID,title,image,price,description,category,promotion,rating,numberRank,customer);
            }
        });

        if(holder.promotion.getText().equals("none")) {
            holder.promotion.setVisibility(View.GONE);
            holder.oldprice.setVisibility(View.GONE);
        }

        else{
            if(products.get(position).price.toString().indexOf(",") != -1){
                products.get(position).price.toString().replace(",",".");
            }
            String promotion = products.get(position).promotion.toString();
            System.out.println(promotion);
            int percIndex = promotion.indexOf('%');
            String salesString = promotion.substring(0,percIndex);
            Double saleNumber = Double.parseDouble(salesString);
            Double sale = products.get(position).price * saleNumber/100;
            Double finalPrice = products.get(position).price - sale;
            priceFloat = Double.parseDouble(finalPrice.toString());
            priceRounded = String.format("%.2f", priceFloat);
            holder.price.setText(priceRounded.replace(".",",") + "$");
            String oldPriceRounded = String.format("%.2f", products.get(position).price);
            holder.oldprice.setText(oldPriceRounded.replace(".",",") + "$");

        }





    }

    @Override
    public int getItemCount() {
        return products.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView image;
        TextView title;
        TextView price;
        RatingBar ratingBar;
        TextView category;
        TextView promotion;
        TextView oldprice;
        TextView UID;
        TextView description;
        TextView numberRank;


        public ViewHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.cardCustomerProduct_Photo);
            title = itemView.findViewById(R.id.cardCustomerProduct_Title);
            price = itemView.findViewById(R.id.cardCustomerProduct_Price);
            ratingBar = itemView.findViewById(R.id.cardCustomerProduct_RatingBar);
            category = itemView.findViewById(R.id.cardCustomerProduct_Category);
            promotion = itemView.findViewById(R.id.cardCustomerProductPromotion);
            oldprice = itemView.findViewById(R.id.cardCustomerProductOldPrice);
            UID = itemView.findViewById(R.id.cardCustomerProduct_UID);
            description = itemView.findViewById(R.id.cardCustomerProduct_Description);
            numberRank = itemView.findViewById(R.id.cardCustomerProduct_numberRank);
        }
    }
}
package com.example.softwarehouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.SearchView;
import androidx.constraintlayout.motion.widget.OnSwipe;
import androidx.core.content.ContextCompat;
import androidx.core.view.GestureDetectorCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.MotionEventCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.softwarehouse.adapters.AdminNormalProductListAdapter;
import com.example.softwarehouse.adapters.CustomerNormalProductAdapter;
import com.example.softwarehouse.model.CustomerModel;
import com.example.softwarehouse.model.ProductModel;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class HomeCustomerActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    ListView listView;
    Toast toastSearchMessage;
    private CustomerModel customer;
    private  ArrayList<ProductModel> products;
    private DrawerLayout mDrawerLayout;
    private boolean statusSideBar;
    private SearchView searchView;
    ArrayList<ProductModel> productsInEvidance;
    ArrayList<ProductModel> productsDiscounted;
    ArrayList<ProductModel> productsGames;
    ArrayList<ProductModel> productsUtility;
    ArrayList<ProductModel> productsPhotoEditing;
    ArrayList<ProductModel> productsVideoMaking;
    ArrayList<ProductModel> productsFinance;
    ArrayList<ProductModel> productsProductivity;
    ArrayList<ProductModel> productsEntertainment;
    HashMap<String,String> user;
    ArrayList<ProductModel> wishlist;


    public void openSideBarMenu(View view){
        if(statusSideBar == false){
            mDrawerLayout.openDrawer(GravityCompat.START);
            statusSideBar = true;
        }
        else{
            mDrawerLayout.closeDrawer(GravityCompat.START);
            statusSideBar = false;
        }
    }

    private void setNavigationViewListener() {
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view_menu_customer);
        navigationView.setNavigationItemSelectedListener(this);
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        switch (item.getItemId()) {

            case R.id.Home_Cutstomer_Button_Side_Menu: {
                Intent refresh = new Intent(this, HomeCustomerActivity.class);
                refresh.putExtra("user",user);
                refresh.putExtra("wishlist",wishlist);
                System.out.println(wishlist);

                startActivity(refresh);
                break;
            }
            case R.id.Wishlist_Customer_Button_Side_Menu: {
                Intent refresh = new Intent(this, WishListActivity.class);
                refresh.putExtra("user",user);
                refresh.putExtra("wishlist",wishlist);
                //System.out.println(wishlist);
                startActivity(refresh);
                break;
            }
            case R.id.Customer_Logout_Button_Side_Menu: {
                startActivity(new Intent(HomeCustomerActivity.this,LoginActivity.class));
                break;
            }
        }
        //close navigation drawer
        mDrawerLayout.closeDrawer(GravityCompat.START);
        statusSideBar = false;
        CloseView();
        return true;
    }

    private void CloseView(){
        System.out.println("chiudo la view");
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_customer);
        System.out.println("HELLO ---------------------------------------------");
        mDrawerLayout = (DrawerLayout) findViewById(R.id.side_navigation_menu_customer);
        user = (HashMap<String,String>)getIntent().getSerializableExtra("user");
        wishlist = (ArrayList<ProductModel>) getIntent().getSerializableExtra("wishlist");
        customer = new CustomerModel(user.get("UID"),user.get("name"),user.get("surname"),user.get("email"),user.get("password"), wishlist);
        productsInEvidance = new ArrayList<>();
        productsDiscounted= new ArrayList<>();
        productsGames = new ArrayList<>();
        productsUtility = new ArrayList<>();
        productsPhotoEditing = new ArrayList<>();
        productsVideoMaking= new ArrayList<>();
        productsFinance= new ArrayList<>();
        productsProductivity= new ArrayList<>();
        productsEntertainment = new ArrayList<>();
        Firebase.GetAllProductsCustomerActivity(this);
        setNavigationViewListener();
        statusSideBar = false;
    }




    public void initProducts(ArrayList<ProductModel>productsInEvidance, ArrayList<ProductModel>productsDiscounted, ArrayList<ProductModel>productsGames, ArrayList<ProductModel>productsUtility, ArrayList<ProductModel>productsPhotoEditing, ArrayList<ProductModel>productsVideoMaking, ArrayList<ProductModel>productsFinance, ArrayList<ProductModel>productsProductivity, ArrayList<ProductModel>productsEntertainment){
        this.productsInEvidance = productsInEvidance;
        this.productsDiscounted = productsDiscounted;
        this.productsGames = productsGames;
        this.productsUtility = productsUtility;
        this.productsPhotoEditing = productsPhotoEditing;
        this.productsVideoMaking = productsVideoMaking;
        this.productsFinance = productsFinance;
        this.productsProductivity = productsProductivity;
        this.productsEntertainment = productsEntertainment;

        productsInEvidance.forEach(productModel -> System.out.println("inEvidance: " + productModel.title));
        productsDiscounted.forEach(productModel -> System.out.println("discunted: " +productModel.title));
        productsGames.forEach(productModel -> System.out.println("games: " +productModel.title));
        productsUtility.forEach(productModel -> System.out.println("utility: " +productModel.title));
        productsPhotoEditing.forEach(productModel -> System.out.println("photo: " +productModel.title));
        productsVideoMaking.forEach(productModel -> System.out.println("video: " +productModel.title));
        productsFinance.forEach(productModel -> System.out.println("fiannce: " +productModel.title));
        productsProductivity.forEach(productModel -> System.out.println("productivity: " +productModel.title));
        productsEntertainment.forEach(productModel -> System.out.println("entertainme: " +productModel.title));
        initList();
    }



    public void initList(){
        RecyclerView.Adapter adapter;
        TextView title;
        RecyclerView recyclerView;
        if(!productsInEvidance.isEmpty()){
            System.out.println("entro dentro InEvidence");
            recyclerView = findViewById(R.id.InEvidenceList);
            adapter = new CustomerNormalProductAdapter(this,productsInEvidance,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.TextView_InEvidenceList);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.InEvidenceList);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsDiscounted.isEmpty()){
            System.out.println("entro dentro Discount");
            recyclerView = findViewById(R.id.DiscountedList);
            adapter = new CustomerNormalProductAdapter(this,productsDiscounted,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.TextView_DiscountedList);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.DiscountedList);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsGames.isEmpty()){
            System.out.println("entro dentro Games");
            recyclerView = findViewById(R.id.GameProducts);
            adapter = new CustomerNormalProductAdapter(this,productsGames,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.textView_GamesCatTitle);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.GameProducts);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsUtility.isEmpty()){
            recyclerView = findViewById(R.id.UtilityProducts);
            adapter = new CustomerNormalProductAdapter(this,productsUtility,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.textView_UtilityCatTitle);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.UtilityProducts);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsPhotoEditing.isEmpty()){
            recyclerView = findViewById(R.id.PhotoEditingProducts);
            adapter = new CustomerNormalProductAdapter(this,productsPhotoEditing,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.textView_PhotoEditingCatTitle);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.PhotoEditingProducts);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsVideoMaking.isEmpty()){
            recyclerView = findViewById(R.id.VideoMakingProducts);
            adapter = new CustomerNormalProductAdapter(this,productsVideoMaking,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.textView_VideoMakingCatTitle);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.VideoMakingProducts);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsFinance.isEmpty()){
            recyclerView = findViewById(R.id.FinanceProducts);
            adapter = new CustomerNormalProductAdapter(this,productsFinance,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.textView_FinanceCatTitle);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.FinanceProducts);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsProductivity.isEmpty()){
            recyclerView = findViewById(R.id.ProductivityProducts);
            adapter = new CustomerNormalProductAdapter(this,productsProductivity,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.textView_ProductivityCatTitle);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.ProductivityProducts);
            recyclerView.setVisibility(View.GONE);
        }

        if(!productsEntertainment.isEmpty()){
            recyclerView = findViewById(R.id.EntertainmentProducts);
            adapter = new CustomerNormalProductAdapter(this,productsEntertainment,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
        else{
            title = findViewById(R.id.textView_EntertainmentCatTitle);
            title.setVisibility(View.GONE);
            recyclerView = findViewById(R.id.EntertainmentProducts);
            recyclerView.setVisibility(View.GONE);
        }

        if(productsInEvidance.isEmpty() && productsDiscounted.isEmpty() && productsProductivity.isEmpty() && productsEntertainment.isEmpty() && productsGames.isEmpty() && productsUtility.isEmpty() && productsPhotoEditing.isEmpty() && productsVideoMaking.isEmpty() && productsFinance.isEmpty()){
            TextView inEvidence = findViewById(R.id.text_InEvidence);
            TextView Category = findViewById(R.id.TextView_CategoryList);
            TextView empty = findViewById(R.id.TextView_Empty);
            inEvidence.setVisibility(View.GONE);
            Category.setVisibility(View.GONE);
            empty.setVisibility(View.VISIBLE);
        }






    }






    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Intent refresh = new Intent(this, HomeCustomerActivity.class);
        Object wishlistnew = data;
        if(wishlistnew != null){
            System.out.println("nuova wishlist");
            ArrayList<ProductModel> wishlist = (ArrayList<ProductModel>) data.getSerializableExtra("wishlist");
            refresh.putExtra("user",user);
            refresh.putExtra("wishlist",wishlist);
            System.out.println(wishlist);
            startActivity(refresh);
            this.finish();
        }
        else{
            System.out.println("vecchia wishlist");
            refresh.putExtra("user",user);
            refresh.putExtra("wishlist",this.wishlist);
            System.out.println(wishlist);
            startActivity(refresh);
            this.finish();
        }




    }
    public void Refresh(){
        Intent refresh = new Intent(this, HomeCustomerActivity.class);
        refresh.putExtra("user",user);
        refresh.putExtra("wishlist",wishlist);
        startActivity(refresh);
        this.finish();
    }




    public void ShowDetails(String UID,String title,String image,String price,String description,String category,String promotion,String rating,String numberRank,CustomerModel customer ) {
        Intent intent = new Intent(HomeCustomerActivity.this, DetailsProductCustomerActivity.class);
        intent.putExtra("UID",UID);
        intent.putExtra("title",title);
        intent.putExtra("image",image);
        intent.putExtra("price",price);
        intent.putExtra("description",description);
        intent.putExtra("category",category);
        intent.putExtra("promotion",promotion);
        intent.putExtra("rating",rating);
        intent.putExtra("numberRank",numberRank);
        intent.putExtra("wishlist",customer.wishlist);
        intent.putExtra("user",customer);
        startActivityForResult(intent,1);
    }
}
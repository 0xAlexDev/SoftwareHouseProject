package com.example.softwarehouse.model;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CustomerModel extends UserModel implements Serializable {
    public ArrayList<ProductModel> wishlist;

    public CustomerModel(String UID, String name, String surname, String password, String email, ArrayList<ProductModel> wishlist){
        super(UID,name,surname,password,email);
        this.wishlist = wishlist;
    }
}

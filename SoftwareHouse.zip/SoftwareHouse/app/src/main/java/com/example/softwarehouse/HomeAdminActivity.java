package com.example.softwarehouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.SearchView;
import androidx.constraintlayout.motion.widget.OnSwipe;
import androidx.core.content.ContextCompat;
import androidx.core.view.GestureDetectorCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.MotionEventCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.softwarehouse.adapters.AdminNormalProductListAdapter;
import com.example.softwarehouse.model.ProductModel;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class HomeAdminActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    ListView listView;
    Toast toastSearchMessage;

    private  ArrayList<ProductModel> products;
    private DrawerLayout mDrawerLayout;
    private boolean statusSideBar;
    private SearchView searchView;
    AdminNormalProductListAdapter adapter;
    Boolean stopUserInteractions;

    public void openSideBarMenu(View view){
        if(statusSideBar == false){
            mDrawerLayout.openDrawer(GravityCompat.START);
            statusSideBar = true;
        }
        else{
            mDrawerLayout.closeDrawer(GravityCompat.START);
            statusSideBar = false;
        }
    }

    public void setInteraction(){
        stopUserInteractions = true;
    }
    private void setNavigationViewListener() {
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view_menu_admin);
        navigationView.setNavigationItemSelectedListener(this);
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        switch (item.getItemId()) {

            case R.id.Home_Admin_Button_Side_Menu: {
                startActivity(new Intent(HomeAdminActivity.this,HomeAdminActivity.class));
                stopUserInteractions=true;
                break;
            }
            case R.id.Admin_Logout_Button_Side_Menu: {
                startActivity(new Intent(HomeAdminActivity.this,LoginActivity.class));
                stopUserInteractions=true;
                break;
            }
        }
        //close navigation drawer
        mDrawerLayout.closeDrawer(GravityCompat.START);
        statusSideBar = false;
        CloseView();
        return true;
    }

    private void CloseView(){
        System.out.println("chiudo la view");
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_admin);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.side_navigation_menu_admin);
        HashMap<String,String> user = (HashMap<String,String>)getIntent().getSerializableExtra("user");
        products = new ArrayList<>();
        Firebase.GetAllProductsAdminActivity(this);
        setNavigationViewListener();
        statusSideBar = false;
        searchView = (SearchView) findViewById(R.id.searchView);
        searchView.clearFocus();
        stopUserInteractions = false;
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return false;
            }
        });

        int id = searchView.getContext().getResources().getIdentifier("android:id/search_src_text", null, null);
        TextView textView = (TextView) searchView.findViewById(id);
        textView.setTextColor(Color.WHITE);
        id = searchView.getContext().getResources().getIdentifier("android:id/search_button", null, null);
        ImageView searchIcon = searchView.findViewById(id);
        searchIcon.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.ic_baseline_search_24));

        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animationOpenSearchView();
            }
        });
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                animationCloseSearchView();
                return false;
            }
        });





    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (stopUserInteractions) {
            return true;
        } else {
            return super.dispatchTouchEvent(ev);
        }
    }
    private void animationOpenSearchView(){

        System.out.println("animazione start ----------");
        ValueAnimator widthAnimator = ValueAnimator.ofInt(searchView.getWidth(), 600);
        widthAnimator.setDuration(500);
        widthAnimator.setInterpolator(new DecelerateInterpolator());
        widthAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                searchView.getLayoutParams().width = (int) animation.getAnimatedValue();
                searchView.requestLayout();
            }
        });
        widthAnimator.start();
    }
    private void animationCloseSearchView(){

        System.out.println("animazione start ----------");
        ValueAnimator widthAnimator = ValueAnimator.ofInt(searchView.getWidth(), 140);
        widthAnimator.setDuration(500);
        widthAnimator.setInterpolator(new DecelerateInterpolator());
        widthAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                searchView.getLayoutParams().width = (int) animation.getAnimatedValue();
                searchView.requestLayout();
            }
        });
        widthAnimator.start();
    }


    private void filterList(String newText){
        ArrayList<ProductModel> filteredList = new ArrayList<>();
        for (ProductModel product : this.products){
            if(product.title.toLowerCase().contains(newText.toLowerCase())){
                filteredList.add(product);
            }
        }

        if(filteredList.isEmpty()){
            if (toastSearchMessage!= null) {
                toastSearchMessage.cancel();
            }
            toastSearchMessage= Toast.makeText(this, "No Product Found", Toast.LENGTH_SHORT);
            toastSearchMessage.show();
            ArrayList<ProductModel> filteredListEmpty = new ArrayList<>();
            adapter.setFilteredByText(filteredListEmpty);

        }
        else{
            adapter.setFilteredByText(filteredList);
        }

    }


    public void initProducts(ArrayList<ProductModel>products){
        this.products = products;
        initList();
    }



    public void initList(){
        RecyclerView recyclerView = findViewById(R.id.dynamicProductListAdmin);
        adapter = new AdminNormalProductListAdapter(this,products,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

    }

    public void GoToAddNewProductActivity(View view){
        stopUserInteractions = true;
        startActivityForResult(new Intent(HomeAdminActivity.this, AddNewProductActivity.class),1);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        stopUserInteractions = false;
            Intent refresh = new Intent(this, HomeAdminActivity.class);
            startActivity(refresh);

            this.finish();

    }
    public void Refresh(){
        Intent refresh = new Intent(this, HomeAdminActivity.class);
        startActivity(refresh);
        this.finish();
    }

    public void GoToEditProduct(String UID,String title,String image,String price,String description,String category,String promotion,String rating,String numberRank ){
        Intent intent = new Intent(HomeAdminActivity.this, EditProductActivity.class);
        intent.putExtra("UID",UID);
        intent.putExtra("title",title);
        intent.putExtra("image",image);
        intent.putExtra("price",price);
        intent.putExtra("description",description);
        intent.putExtra("category",category);
        intent.putExtra("promotion",promotion);
        intent.putExtra("rating",rating);
        intent.putExtra("numberRank",numberRank);
        startActivityForResult(intent,1);
    }


    public void ShowDetails(String UID,String title,String image,String price,String description,String category,String promotion,String rating,String numberRank ) {
        Intent intent = new Intent(HomeAdminActivity.this, DetailsProductAdminActivity.class);
        intent.putExtra("UID",UID);
        intent.putExtra("title",title);
        intent.putExtra("image",image);
        intent.putExtra("price",price);
        intent.putExtra("description",description);
        intent.putExtra("category",category);
        intent.putExtra("promotion",promotion);
        intent.putExtra("rating",rating);
        intent.putExtra("numberRank",numberRank);
        startActivityForResult(intent,1);
    }
}
package com.example.softwarehouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.SearchView;
import androidx.constraintlayout.motion.widget.OnSwipe;
import androidx.core.content.ContextCompat;
import androidx.core.view.GestureDetectorCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.MotionEventCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.softwarehouse.adapters.AdminNormalProductListAdapter;
import com.example.softwarehouse.adapters.CustomerNormalProductAdapter;
import com.example.softwarehouse.adapters.WishlistAdapter;
import com.example.softwarehouse.model.CustomerModel;
import com.example.softwarehouse.model.ProductModel;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class WishListActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    ListView listView;
    Toast toastSearchMessage;
    private CustomerModel customer;
    private  ArrayList<ProductModel> products;
    private DrawerLayout mDrawerLayout;
    private boolean statusSideBar;
    private SearchView searchView;
    ArrayList<ProductModel> allProducts;
    HashMap<String,String> user;
    ArrayList<ProductModel> wishlist;


    public void openSideBarMenu(View view){
        if(statusSideBar == false){
            mDrawerLayout.openDrawer(GravityCompat.START);
            statusSideBar = true;
        }
        else{
            mDrawerLayout.closeDrawer(GravityCompat.START);
            statusSideBar = false;
        }
    }

    private void setNavigationViewListener() {
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view_menu_customer);
        navigationView.setNavigationItemSelectedListener(this);
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        switch (item.getItemId()) {

            case R.id.Home_Cutstomer_Button_Side_Menu: {
                Intent refresh = new Intent(this, HomeCustomerActivity.class);
                refresh.putExtra("user",user);
                refresh.putExtra("wishlist",wishlist);
                System.out.println(wishlist);
                startActivity(refresh);
                break;
            }
            case R.id.Wishlist_Customer_Button_Side_Menu: {
                Intent refresh = new Intent(this, WishListActivity.class);
                refresh.putExtra("user",user);
                refresh.putExtra("wishlist",wishlist);
                System.out.println(wishlist);
                startActivity(refresh);
                break;
            }
            case R.id.Customer_Logout_Button_Side_Menu: {
                startActivity(new Intent(this,LoginActivity.class));
                break;
            }
        }
        //close navigation drawer
        mDrawerLayout.closeDrawer(GravityCompat.START);
        statusSideBar = false;
        CloseView();
        return true;
    }

    private void CloseView(){
        System.out.println("chiudo la view");
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wish_list);
        System.out.println("HELLO ---------------------------------------------");
        mDrawerLayout = (DrawerLayout) findViewById(R.id.side_navigation_menu_customer);
        user = (HashMap<String,String>)getIntent().getSerializableExtra("user");
        wishlist = (ArrayList<ProductModel>) getIntent().getSerializableExtra("wishlist");
        customer = new CustomerModel(user.get("UID"),user.get("name"),user.get("surname"),user.get("email"),user.get("password"), wishlist);

        for(ProductModel product : wishlist){
            System.out.println("-----------------" + product.title);
        }
        allProducts = new ArrayList<>();
        Firebase.GetAllProductsWishlistActivity(this);
        setNavigationViewListener();
        statusSideBar = false;
    }




    public void initProducts(ArrayList<ProductModel>allProducts){
        this.allProducts = allProducts;
        initList();
    }



    public void initList(){
        RecyclerView.Adapter adapter;
        RecyclerView recyclerView;

        ArrayList<ProductModel> wishlistFinal = new ArrayList<>();

        for (ProductModel product : wishlist){
            for(ProductModel product2 : allProducts){
                if(product.UID.toLowerCase().equals(product2.UID.toLowerCase())){
                    wishlistFinal.add(product);
                }
            }
        }

            System.out.println("entro dentro InEvidence");
            recyclerView = findViewById(R.id.ListWishlist);
            adapter = new WishlistAdapter(this,wishlistFinal,allProducts,this,customer);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));






    }






    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data!=null) {
            Intent refresh = new Intent(this, WishListActivity.class);
            refresh.putExtra("user", user);
            refresh.putExtra("wishlist", wishlist);
            System.out.println(wishlist);
            startActivity(refresh);
            this.finish();
        }




    }
    public void Refresh(){
        Intent refresh = new Intent(this, HomeCustomerActivity.class);
        refresh.putExtra("user",user);
        refresh.putExtra("wishlist",wishlist);
        startActivity(refresh);
        this.finish();
    }




    public void ShowDetails(String UID,String title,String image,String price,String description,String category,String promotion,String rating,String numberRank,CustomerModel customer ) {
        Intent intent = new Intent(WishListActivity.this, DetailsProductCustomerActivity.class);
        intent.putExtra("UID",UID);
        intent.putExtra("title",title);
        intent.putExtra("image",image);
        intent.putExtra("price",price);
        intent.putExtra("description",description);
        intent.putExtra("category",category);
        intent.putExtra("promotion",promotion);
        intent.putExtra("rating",rating);
        intent.putExtra("numberRank",numberRank);
        intent.putExtra("wishlist",customer.wishlist);
        intent.putExtra("user",customer);
        intent.putExtra("caller","2");
        startActivityForResult(intent,1);
    }
}
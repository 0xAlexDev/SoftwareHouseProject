package com.example.softwarehouse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.softwarehouse.model.UserModel;
import com.google.firebase.auth.FirebaseAuth;

import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                StartApp();
            }
        }, 2000);




    }
    private void StartApp(){
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
        finish();
    }




}
package com.example.softwarehouse;

import android.app.Activity;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.android.billingclient.api.Purchase;
import com.example.softwarehouse.model.ProductModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;


public class Firebase {

    public static void SaveData(String collection, Map<String, Object> object) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection(collection)
                .add(object)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        System.out.println("Firebase - NoUniqueObject insert done");

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {


                    }
                });
    }

    public static void SaveNewProduct(Map<String, Object> object,AddNewProductActivity activity,String pathFirebaseImage) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Double priceFloat = Double.parseDouble(object.get("price").toString());
        String priceRounded = String.format("%.2f", priceFloat);
        object.put("price",priceRounded.replace(",","."));
        db.collection("Products")
                .add(object)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        activity.uploadImage(pathFirebaseImage, documentReference.getId().toString());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {


                    }
                });
    }

    public static void SaveDataUser(String collection, String UID, Map<String, Object> object,RegisterActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference doc = db.collection(collection).document(UID);
                doc.set(object).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        System.out.println("utente registrato");
                        activity.CallbackRegister(1);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        System.out.println("probemi durante la registrazione dedll'utente");
                        activity.CallbackRegister(-1);
                    }
                });
    }
    public static void SaveDataUser(String collection, String UID, Map<String, Object> object,DetailsProductCustomerActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        System.out.println(UID);
        DocumentReference doc = db.collection(collection).document(UID);
        doc.set(object).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

                activity.callBackUpdateWishlist();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                activity.callBackUpdateWishlist();
            }
        });
    }


    public static void ModifyProducts(String UID, Map<String, Object> object, EditProductActivity activity, String newImage, String oldIamge){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Double priceFloat = Double.parseDouble(object.get("price").toString());
        String priceRounded = String.format("%.2f", priceFloat);
        object.put("price",priceRounded.replace(",","."));
        db.collection("Products").document(UID)
                .set(object)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        activity.uploadImage(newImage,oldIamge);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                    }
                });


    }

    public static void ModifyProducts(String UID, Map<String, Object> object, DetailsProductCustomerActivity activity, String newImage, String oldIamge){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Double priceFloat = Double.parseDouble(object.get("price").toString());
        String priceRounded = String.format("%.2f", priceFloat);
        object.put("price",priceRounded.replace(",","."));
        db.collection("Products").document(UID)
                .set(object)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        activity.updateUserWishlist(1,Integer.parseInt((String) object.get("rating")),Integer.parseInt((String)object.get("numberRank")));
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                    }
                });


    }

    public static void DeleteProducts(String UID, String image, HomeAdminActivity activity){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Products").document(UID)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {


                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(image);

                        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                activity.Refresh();
                                Toast.makeText(activity,"Product deleted",
                                        Toast.LENGTH_SHORT).show();
                                // File deleted successfully
                                //Log.d(TAG, "onSuccess: deleted file")

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Uh-oh, an error occurred!
                                //Log.d(TAG, "onFailure: did not delete file");
                            }
                        });



                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });


    }
    public static void DeleteProductsWithoutImage(String UID, AddNewProductActivity activity){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Products").document(UID)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {


                        System.out.println("eliminato il record per problemi di rete");



                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });


    }

    public static void GetAllProductsAdminActivity(HomeAdminActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Products").orderBy("title").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                ArrayList<ProductModel> products = new ArrayList<>();
                for(DocumentSnapshot product : queryDocumentSnapshots){
                    String UID = product.getId().toString();
                    String image = product.getString("image").toString();
                    String title = product.getString("title").toString();
                    String category = product.getString("category").toString();
                    String description = product.getString("description").toString();
                    String promotion = product.getString("promotion").toString();
                    Double price = Double.parseDouble(product.getString("price").toString().replace(",","."));
                    Double oldprice = Double.parseDouble(product.getString("oldprice").toString().replace(",","."));
                    Integer rating = Integer.parseInt(product.getString("rating").toString());
                    Integer numberRank = Integer.parseInt(product.getString("numberRank").toString());
                    ProductModel p = new ProductModel(UID,image,title,description,category,price,rating,promotion,oldprice,numberRank);
                    products.add(p);
                }
                activity.initProducts(products);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                System.out.println("problemi");
            }
        });

    }

    public static void GetAllProductsWishlistActivity(WishListActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Products").orderBy("title").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                ArrayList<ProductModel> products = new ArrayList<>();
                for(DocumentSnapshot product : queryDocumentSnapshots){
                    String UID = product.getId().toString();
                    String image = product.getString("image").toString();
                    String title = product.getString("title").toString();
                    String category = product.getString("category").toString();
                    String description = product.getString("description").toString();
                    String promotion = product.getString("promotion").toString();
                    Double price = Double.parseDouble(product.getString("price").toString().replace(",","."));
                    Double oldprice = Double.parseDouble(product.getString("oldprice").toString().replace(",","."));
                    Integer rating = Integer.parseInt(product.getString("rating").toString());
                    Integer numberRank = Integer.parseInt(product.getString("numberRank").toString());
                    ProductModel p = new ProductModel(UID,image,title,description,category,price,rating,promotion,oldprice,numberRank);
                    products.add(p);
                }
                activity.initProducts(products);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                System.out.println("problemi");
            }
        });

    }

    public static void GetAllProductsCustomerActivity(HomeCustomerActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Products").orderBy("title").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                ArrayList<ProductModel> productsInEvidance = new ArrayList<>();
                ArrayList<ProductModel> productsDiscounted= new ArrayList<>();
                ArrayList<ProductModel> productsGames = new ArrayList<>();
                ArrayList<ProductModel> productsUtility = new ArrayList<>();
                ArrayList<ProductModel> productsPhotoEditing = new ArrayList<>();
                ArrayList<ProductModel> productsVideoMaking= new ArrayList<>();
                ArrayList<ProductModel> productsFinance= new ArrayList<>();
                ArrayList<ProductModel> productsProductivity= new ArrayList<>();
                ArrayList<ProductModel> productsEntertainment = new ArrayList<>();
                for(DocumentSnapshot product : queryDocumentSnapshots){
                    String UID = product.getId().toString();
                    String image = product.getString("image").toString();
                    String title = product.getString("title").toString();
                    String category = product.getString("category").toString();
                    String description = product.getString("description").toString();
                    String promotion = product.getString("promotion").toString();
                    Double price = Double.parseDouble(product.getString("price").toString().replace(",","."));
                    Double oldprice = Double.parseDouble(product.getString("oldprice").toString().replace(",","."));
                    Integer rating = Integer.parseInt(product.getString("rating").toString());
                    Integer numberRank = Integer.parseInt(product.getString("numberRank").toString());
                    ProductModel p = new ProductModel(UID,image,title,description,category,price,rating,promotion,oldprice,numberRank);
                    Boolean flag = false;
                    if(numberRank>0){
                        if((rating/numberRank)>=4 ){
                            productsInEvidance.add(p);
                            flag = true;
                        }
                    }


                    if(!promotion.equals("none") && flag == false){
                        productsDiscounted.add(p);
                    }
                    else {
                        flag = false;
                    }


                    if(category.toLowerCase().equals("games")){
                        productsGames.add(p);
                    }
                    if(category.toLowerCase().equals("utility")){
                        productsUtility.add(p);
                    }
                    if(category.toLowerCase().equals("photoediting")){
                        productsPhotoEditing.add(p);
                    }
                    if(category.toLowerCase().equals("videomaking")){
                        productsVideoMaking.add(p);
                    }
                    if(category.toLowerCase().equals("finance")){
                        productsFinance.add(p);
                    }
                    if(category.toLowerCase().equals("productivity")){
                        productsProductivity.add(p);
                    }
                    if(category.toLowerCase().equals("entertainment")){
                        productsEntertainment.add(p);
                    }
                }
                activity.initProducts(productsInEvidance,productsDiscounted,productsGames,productsUtility,productsPhotoEditing,productsVideoMaking,productsFinance,productsProductivity,productsEntertainment);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                System.out.println("problemi");
            }
        });

    }

    public static void GetAllProducts(String collection, String ID, HomeAdminActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference doc = db.collection(collection).document(ID);
        doc.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                DocumentSnapshot result = documentSnapshot;
                System.out.println(result);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

    }

    public static void GetDataUser(String ID,LoginActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference doc = db.collection("Users").document(ID);
        doc.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                HashMap<String,Object> user = new HashMap<>();
                user.put("UID",documentSnapshot.getId().toString());
                user.put("name",documentSnapshot.getString("name"));
                user.put("surname",documentSnapshot.getString("surname"));
                user.put("email",documentSnapshot.getString("email"));
                user.put("password",documentSnapshot.getString("password"));
                ArrayList <ProductModel>wishlist = new ArrayList<>();
                ArrayList <HashMap<String,Object>> listFirebase = (ArrayList<HashMap<String,Object>>)documentSnapshot.getData().get("wishlist");
                for(HashMap<String,Object> product : listFirebase){
                    String UID = product.get("UID").toString();
                    String title = product.get("title").toString();
                    String image = product.get("image").toString();
                    Float price = Float.parseFloat(product.get("price").toString());
                    Float oldprice = Float.parseFloat(product.get("oldprice").toString());
                    String description = product.get("description").toString();;
                    String category = product.get("category").toString();
                    String promotion = product.get("promotion").toString();
                    Integer rating = Integer.parseInt(product.get("rating").toString());
                    Integer numberRank = Integer.parseInt(product.get("numberRank").toString());
                    wishlist.add(new ProductModel(UID,image,title,description,category,Double.parseDouble(price.toString()),rating,promotion,Double.parseDouble(oldprice.toString()),numberRank));
                }


                activity.CallbackLogin(1,user,wishlist,ID);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                activity.CallbackLogin(-1,null,null,null);
            }
        });

    }

    public static void GetDataUser(String ID,HomeCustomerActivity activity) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference doc = db.collection("Users").document(ID);
        doc.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                HashMap<String,Object> user = new HashMap<>();
                user.put("UID",documentSnapshot.getId().toString());
                user.put("name",documentSnapshot.getString("name"));
                user.put("surname",documentSnapshot.getString("surname"));
                user.put("email",documentSnapshot.getString("email"));
                user.put("password",documentSnapshot.getString("password"));
                ArrayList <ProductModel>wishlist = new ArrayList<>();
                ArrayList <HashMap<String,Object>> listFirebase = (ArrayList<HashMap<String,Object>>)documentSnapshot.getData().get("wishlist");
                for(HashMap<String,Object> product : listFirebase){
                    String UID = product.get("UID").toString();
                    String title = product.get("title").toString();
                    String image = product.get("image").toString();
                    Float price = Float.parseFloat(product.get("price").toString());
                    Float oldprice = Float.parseFloat(product.get("oldprice").toString());
                    String description = product.get("description").toString();;
                    String category = product.get("category").toString();
                    String promotion = product.get("promotion").toString();
                    Integer rating = Integer.parseInt(product.get("rating").toString());
                    Integer numberRank = Integer.parseInt(product.get("numberRank").toString());
                    wishlist.add(new ProductModel(UID,image,title,description,category,Double.parseDouble(price.toString()),rating,promotion,Double.parseDouble(oldprice.toString()),numberRank));
                }


                //activity.getDataUser(1,user,wishlist,ID);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                //activity.get(-1,null,null,null);
            }
        });

    }

    public static void Login(String email, String password, LoginActivity activity) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            String email = user.getEmail();
                            boolean emailVerified = user.isEmailVerified();
                            if(emailVerified == true){
                                activity.GetDataUser(user.getUid().toString());
                            }
                            else{
                                activity.CallbackLogin(-1,null,null,null);
                            }

                            //updateUI(user);
                        } else {
                            activity.CallbackLogin(-1,null,null,null);
                        }
                    }
                });
    }




    public static void Register(String email, String password,String name,String surname,RegisterActivity activity) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            user.sendEmailVerification();
                            String UID = user.getUid().toString();
                            activity.CallbackRegister(name,surname,email,password,UID);
                            //updateUI(user);
                        } else {
                            System.out.println("user problem");
                            activity.CallbackRegister(-1);
                        }
                    }
                });
    }



}

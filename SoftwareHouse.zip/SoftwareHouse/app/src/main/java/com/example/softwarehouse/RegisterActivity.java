package com.example.softwarehouse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.softwarehouse.model.ProductModel;
import com.example.softwarehouse.model.UserModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    Boolean stopUserInteractions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        stopUserInteractions = false;
    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (stopUserInteractions) {
            return true;
        } else {
            return super.dispatchTouchEvent(ev);
        }
    }

    public void Register(View view){
        String name = ((EditText) findViewById(R.id.editText_RegisterName)).getText().toString().toLowerCase();
        String surname = ((EditText) findViewById(R.id.editText_RegisterSurname)).getText().toString().toLowerCase();
        String email = ((EditText) findViewById(R.id.editText_RegisterEmail)).getText().toString().toLowerCase();
        String password = ((EditText) findViewById(R.id.editText_RegisterPassword)).getText().toString().toLowerCase();

        int checkValidation = ValidationInputRegister(email,password);
        if(checkValidation<0){
            String toast;
            if(checkValidation == -1){
                toast = "Email or Password Are To Short";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }

            else if(checkValidation == -2){
                toast = "Email Is Incorrect";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }

            else if(checkValidation == -3){
                toast = "Domain Not Supported";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }

            else if(checkValidation == -4){
                toast = "Email or Password are Empty";
                Toast.makeText(this.getApplicationContext(),toast,
                        Toast.LENGTH_SHORT).show();
            }



            return;
        }
        if(name.isEmpty() || surname.isEmpty()){
            Toast.makeText(this.getApplicationContext(),"Name or Surname are Empty",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        else if(name.length() < 4 || surname.length()<4){
            Toast.makeText(this.getApplicationContext(),"Name or Surname Are to Short",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        stopUserInteractions = true;
        Firebase.Register(email,password,name,surname,this);
    }



    public void CallbackRegister(int operationState){

        String toast;
        if(operationState == 1){
            Intent intent = new Intent(new Intent(RegisterActivity.this,RegisterRedirectActivity.class));
            String email = ((EditText) findViewById(R.id.editText_RegisterEmail)).getText().toString().toLowerCase();
            intent.putExtra("email",email);
            startActivity(intent);
            finish();
        }

        else if(operationState == -1){
            stopUserInteractions = false;
            toast = "User already exist";
            Toast.makeText(this.getApplicationContext(),toast,
                    Toast.LENGTH_SHORT).show();
        }

    }

    public void CallbackRegister(String name,String surname,String email,String password,String UID){
        Map<String, Object> user = new HashMap<>();
        user.put("name",name);
        user.put("surname",surname);
        user.put("email",email);
        user.put("password",password);
        ArrayList<ProductModel> wishlist = new ArrayList<>();
        wishlist.add(new ProductModel("1312412","123123","asfasfas","fasfasf","fasfasf",0.0,0,"fasfa",0.0,0));
        wishlist.add(new ProductModel("1312412","123123","asfasfas","fasfasf","fasfasf",0.0,0,"fasfa",0.0,0));
        wishlist.add(new ProductModel("1312412","123123","asfasfas","fasfasf","fasfasf",0.0,0,"fasfa",0.0,0));

        user.put("wishlist", wishlist);
        Firebase.SaveDataUser("Users",UID,user,this);
    }

    public void GoToLogin(View view){
        startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
        finish();
        System.out.println("pressed");
    }




    private int ValidationInputRegister(String email,String password){
        if(email.length() > 50 || password.length() > 15 || password.length() < 6){
            return -1;
        }
        int at = email.indexOf("@");
        if(at == -1){
            return -2;
        }

        String domain = email.substring(at+1);
        System.out.println(domain);
        if(!domain.equals("gmail.com") && !domain.equals("outlook.it") && !domain.equals("outlook.com") && !domain.equals("icloud.com") && !domain.equals("yahoo.com")&& !domain.equals("yahoo.it")&& !domain.equals("live.com")&& !domain.equals("hotmail.com")&& !domain.equals("hotmail.it")){
            return -3;
        }

        if(email.isEmpty() || password.isEmpty()){
            return -4;
        }

        return 1;
    }



}

package com.example.softwarehouse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.drawable.IconCompat;

import android.content.Intent;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.softwarehouse.model.CustomerModel;
import com.example.softwarehouse.model.ProductModel;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

public class DetailsProductCustomerActivity extends AppCompatActivity {

    // Uri indicates, where the image will be picked from
    private Uri filePath;

    // request code
    private final int PICK_IMAGE_REQUEST = 22;
    final Handler ha = new Handler();
    Boolean stopUserInteractions;

    // instance for firebase storage and StorageReference
    FirebaseStorage storage;
    StorageReference storageReference;
    String UID;
    String title;
    String image;
    String oldimage;
    String price;
    String description;
    String category;
    String rating;
    String promotion;
    String numberRank;
    CustomerModel customer;
    ArrayList<ProductModel> wishlist;
    Integer caller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_product_customer);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        UID = getIntent().getStringExtra("UID");
        title = getIntent().getStringExtra("title");
        image = getIntent().getStringExtra("image");
        oldimage = getIntent().getStringExtra("image");
        price = getIntent().getStringExtra("price");
        description = getIntent().getStringExtra("description");
        category = getIntent().getStringExtra("category");
        promotion = getIntent().getStringExtra("promotion");
        rating = getIntent().getStringExtra("rating");
        numberRank = getIntent().getStringExtra("numberRank");
        wishlist = new ArrayList<>();
        wishlist = (ArrayList<ProductModel>) getIntent().getSerializableExtra("wishlist");
        customer =  (CustomerModel) getIntent().getSerializableExtra("user");
        stopUserInteractions = false;
        //this.caller = Integer.parseInt(getIntent().getStringExtra("caller"));

        setUpButtonInput();




    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (stopUserInteractions) {
            return true;
        } else {
            return super.dispatchTouchEvent(ev);
        }
    }

    public void GoBack(View view) {

        Intent resultIntent = new Intent();
        // TODO Add extras or a data URI to this intent as appropriate.
        resultIntent.putExtra("wishlist", wishlist);
        resultIntent.putExtra("user",customer);
        setResult(this.RESULT_OK, resultIntent);
        finish();
    }

    public void showToast(String str){
        Toast.makeText(this,str,Toast.LENGTH_SHORT).show();
    }


    public void setUpButtonInput() {

        TextView EditTextTitle = findViewById(R.id.text_titleContentDetailsProduct);
        TextView EditTextPrice = findViewById(R.id.text_priceContentDetailsProducts);
        TextView EditTextDescription = findViewById(R.id.text_descriptionContentDetails);
        TextView category = findViewById(R.id.text_CategoryContentDetailsProduct);
        TextView promotion = findViewById(R.id.text_PromotionContentDetailsProduct);
        EditTextTitle.setText(this.title);
        EditTextDescription.setText(this.description);
        EditTextPrice.setText(this.price.toString().replace(".",",") + "$");
        category.setText(this.category);
        promotion.setText(this.promotion);
        ImageButton image = findViewById(R.id.buntton_ImageDetailsProduct);
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(this.image);
        GlideApp.with(this).asBitmap().load(storageReference).into(image);
        ImageButton backButton = findViewById(R.id.imageButtonSideBarAdmin);

        ImageButton favoriteButton = findViewById(R.id.imageButtonFavorite);
        TextView wishlistText = findViewById(R.id.textViewWishlist);
        Boolean flagWish = false;
        for (ProductModel product : wishlist){
            System.out.println("------------------" + product.title);
            if(UID.toLowerCase().equals(product.UID.toLowerCase())){
                flagWish = true;
            }
        }

        if(flagWish == true){
            favoriteButton.setImageResource(R.drawable.ic_baseline_favorite_24);
            wishlistText.setVisibility(View.GONE);
            favoriteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showToast("The product is already on your wish list!");
                }
            });
        }

        else{
            favoriteButton.setImageResource(R.drawable.ic_baseline_favorite_border_24);
            wishlistText.setVisibility(View.VISIBLE);
            favoriteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                            ConstraintLayout panelVote = findViewById(R.id.panelVote);
                            panelVote.setVisibility(View.VISIBLE);
                            RatingBar ratingBar = findViewById(R.id.RatingBarForVote);
                            ratingBar.setOnTouchListener(new View.OnTouchListener() {

                                @Override
                                public boolean onTouch(View v, MotionEvent event) {
                                    if (event.getAction() == MotionEvent.ACTION_UP) {
                                        float touchPositionX = event.getX();
                                        float width = ratingBar.getWidth();
                                        float starsf = (touchPositionX / width) * 5f;
                                        int stars = (int)starsf+1;
                                        ratingBar.setRating(stars);

                                        v.setPressed(false);
                                    }
                                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                                        v.setPressed(true);
                                    }

                                    if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                                        v.setPressed(false);
                                    }


                                    return true;
                                }});

                            Button buttonDone = findViewById(R.id.buttonDoneVote);
                            buttonDone.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Float vote = ratingBar.getRating();
                                    Integer finalRating = Math.round(vote) + Integer.parseInt(rating);
                                    Integer numberRankFinal = 1 + Integer.parseInt(numberRank);
                                    voteFirebase(finalRating,numberRankFinal);
                                }
                            });

                }
            });
        }

        Float rank;
        if(Integer.parseInt(numberRank) == 0){
            rank = new Float(0.0);
        }
        else{
            rank = Float.parseFloat(String.valueOf(Integer.parseInt(rating)/Integer.parseInt(numberRank)));
        }


        RatingBar ratingBar = findViewById(R.id.DetailsRatingBarAdmin);
        ratingBar.setRating(rank);




    }

    private void voteFirebase(Integer rating, Integer numberRank){
        HashMap<String,Object> JSONproduct = new HashMap<>();
        JSONproduct.put("image", image);
        JSONproduct.put("title", title);
        JSONproduct.put("description", description);
        JSONproduct.put("price", price);
        JSONproduct.put("rating", rating.toString());
        JSONproduct.put("category", category);
        JSONproduct.put("promotion", promotion);
        JSONproduct.put("oldprice", "0");
        JSONproduct.put("numberRank", numberRank.toString());
        System.out.println("---------------------- sto votando");
        stopUserInteractions = true;
        Firebase.ModifyProducts(UID,JSONproduct, this,image,oldimage);
    }

    public  void updateUserWishlist(int i,Integer rating, Integer numberRank){
        if(i>0){
            System.out.println("---------------------- sto aggironanto user");
            HashMap<String,Object> JSONuser = new HashMap<>();
            JSONuser.put("name", customer.name);
            JSONuser.put("surname", customer.surname);
            JSONuser.put("email", customer.email);
            JSONuser.put("password", customer.password);
            wishlist.add(new ProductModel(UID,image,title,description,category,Double.parseDouble(price),rating,promotion,0.0,numberRank ));
            System.out.println("Sto per salvare i segeguenti oggetti");
            for (ProductModel product : wishlist){
                System.out.println(product.title);
            }
            JSONuser.put("wishlist", wishlist);
            System.out.println("--------------- " + customer.UID);
            Firebase.SaveDataUser("Users",customer.UID.toString(),JSONuser,this);
        }


    }

    public void callBackUpdateWishlist(){
        Intent resultIntent = new Intent();
        // TODO Add extras or a data URI to this intent as appropriate.
        resultIntent.putExtra("wishlist", wishlist);
        resultIntent.putExtra("user",customer);
        setResult(this.RESULT_OK, resultIntent);
        System.out.println("---------------------- torno dietro");
        finish();
    }



}







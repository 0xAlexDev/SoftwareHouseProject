package com.example.softwarehouse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class DetailsProductAdminActivity extends AppCompatActivity {

    // Uri indicates, where the image will be picked from
    private Uri filePath;

    // request code
    private final int PICK_IMAGE_REQUEST = 22;
    final Handler ha = new Handler();

    // instance for firebase storage and StorageReference
    FirebaseStorage storage;
    StorageReference storageReference;
    String UID;
    String title;
    String image;
    String oldimage;
    String price;
    String description;
    String category;
    String rating;
    String promotion;
    String numberRank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_product_admin);

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        UID = getIntent().getStringExtra("UID");
        title = getIntent().getStringExtra("title");
        image = getIntent().getStringExtra("image");
        oldimage = getIntent().getStringExtra("image");
        price = getIntent().getStringExtra("price");
        description = getIntent().getStringExtra("description");
        category = getIntent().getStringExtra("category");
        promotion = getIntent().getStringExtra("promotion");
        rating = getIntent().getStringExtra("rating");
        numberRank = getIntent().getStringExtra("numberRank");
        setUpButtonInput();




    }

    public void GoBack(View view) {
        finish();
    }


    public void setUpButtonInput() {

        TextView EditTextTitle = findViewById(R.id.text_titleContentDetailsProduct);
        TextView EditTextPrice = findViewById(R.id.text_priceContentDetailsProducts);
        TextView EditTextDescription = findViewById(R.id.text_descriptionContentDetails);
        TextView category = findViewById(R.id.text_CategoryContentDetailsProduct);
        TextView promotion = findViewById(R.id.text_PromotionContentDetailsProduct);
        EditTextTitle.setText(this.title);
        EditTextDescription.setText(this.description);
        EditTextPrice.setText(this.price.toString().replace(".",",") + "$");
        category.setText(this.category);
        promotion.setText(this.promotion);
        ImageButton image = findViewById(R.id.buntton_ImageDetailsProduct);
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(this.image);
        GlideApp.with(this).asBitmap().load(storageReference).into(image);
        ImageButton backButton = findViewById(R.id.imageButtonSideBarAdmin);

        Float rank;
        if(Integer.parseInt(numberRank) == 0){
            rank = new Float(0.0);
        }
        else{
            rank = Float.parseFloat(String.valueOf(Integer.parseInt(rating)/Integer.parseInt(numberRank)));
        }


        RatingBar ratingBar = findViewById(R.id.DetailsRatingBarAdmin);
        ratingBar.setRating(rank);


    }

}







package com.example.softwarehouse.model;

import java.io.Serializable;
import java.net.URL;

public class UserModel implements Serializable {
    public String UID;
    public String name;
    public String surname;
    public String password;
    public String email;

    UserModel(String UID, String name, String surname, String password, String email){
        this.UID = UID;
        this.name = name;
        this.surname = surname;
        this.password = password;
        this.email = email;
    }


}
